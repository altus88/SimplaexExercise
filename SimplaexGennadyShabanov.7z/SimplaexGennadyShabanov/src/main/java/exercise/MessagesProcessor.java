package exercise;

import java.io.*;

public class MessagesProcessor implements Closeable
{
    private static final int EXPECTED_NUMBER_OF_POINTS = 5;
    private int dataReceivedAfterLastBatchWrite = 0;
    private int fileNumber = 1;
    private MessagesAggregator messagesAggregator;
    private Server server;

    public MessagesProcessor(Server server, MessagesAggregator messagesAggregator)
    {
        this.messagesAggregator = messagesAggregator;
        this.server = server;
    }

    public void acceptRequests() throws IOException
    {
        server.waitForConnections();
        String lastMessagePrevBatch = null;
        try
        {
            while (true)
            {
                String messagesBatch = null;
                messagesBatch = server.readNextBatch();

                String[] messages = messagesBatch.split("\n");
                System.out.println(String.format("%s messages received", messages.length));
                if (messages.length > 0)
                {
                    String firstMessage = messages[0];
                    boolean firstMessageJoined = processLastMessageFromPrevBatch(lastMessagePrevBatch, firstMessage);
                    // make lastMessagePrevBatch null since it was processed
                    lastMessagePrevBatch = null;
                    // if first message of the batch was concatenated with last message of prev batch, then skip processing of the message and
                    int start = firstMessageJoined ? 1 : 0;

                    for (int i = start; i < messages.length; i++)
                    {
                        if (i < messages.length - 1)
                        {
                            String message = messages[i];
                            processMessage(message);
                        } else
                        {
                            // the last line is not processed, since we need to see the first line from the next batch
                            lastMessagePrevBatch = messages[i];
                        }
                    }
                }
            }
        }
        catch (IOException e)
        {
           server.close();
        }
    }

    // a comma can be skipped between UUID and base64 data, the a regex is needed to extract UUID
    private String[] getDataPoints(String message)
    {
        return message.split(",");
    }

    private String concatMessages(String lastLinePrevBatch, String firstLineNextBatch)
    {
        String concatWithComma = String.format("%s,%s", lastLinePrevBatch, firstLineNextBatch);
        if (getDataPoints(concatWithComma).length == EXPECTED_NUMBER_OF_POINTS)
        {
            return concatWithComma;
        }

        String concatWithoutComma = String.format("%s%s", lastLinePrevBatch, firstLineNextBatch);
        if (getDataPoints(concatWithoutComma).length == EXPECTED_NUMBER_OF_POINTS)
        {
            return concatWithoutComma;
        }
        throw new RuntimeException("Unknown case");
    }

    private boolean processLastMessageFromPrevBatch(String lastMessagePrevBatch, String firstMessageNextBatch) throws IOException
    {
        boolean firstMessageJoined = false;
        if (lastMessagePrevBatch != null)
        {
            // if one of the messages have less than EXPECTED_NUMBER_OF_POINTS data points, then first message from the next batch is
            // the continuation of the last message from the previous bath
            if (getDataPoints(lastMessagePrevBatch).length < EXPECTED_NUMBER_OF_POINTS || getDataPoints(firstMessageNextBatch).length < EXPECTED_NUMBER_OF_POINTS)
            {
                String resMessage = concatMessages(lastMessagePrevBatch, firstMessageNextBatch);
                firstMessageJoined = true;
                processMessage(resMessage);
            }
            else
            {
                processMessage(lastMessagePrevBatch);
            }
        }
        return firstMessageJoined;
    }

    private void processMessage(String message) throws IOException
    {
        String[] dataPoints = getDataPoints(message);
        dataReceivedAfterLastBatchWrite++;
        messagesAggregator.aggregateStatistic(dataPoints);

        if (dataReceivedAfterLastBatchWrite % messagesAggregator.getAggregationBatchSize() == 0)
        {
            System.out.println(String.format("Write to file statistic for %s messages", messagesAggregator.getAggregationBatchSize()));
            messagesAggregator.writeDataStatisticToFile(fileNumber);
            messagesAggregator.reinitializeStatistic();
            fileNumber++;
            dataReceivedAfterLastBatchWrite = 0;
        }
    }

    @Override
    public void close() throws IOException
    {
        server.close();
    }

    public static void main(String[] args) throws IOException
    {
        new MessagesProcessor(new Server(), new MessagesAggregator()).acceptRequests();
    }
}