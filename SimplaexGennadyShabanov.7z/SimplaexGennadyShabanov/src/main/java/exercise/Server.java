package exercise;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server implements Closeable
{
    private ServerSocket serverSocket;
    private DataInputStream dis;
    private Socket socket;

    public Server() throws IOException
    {
        this.serverSocket = new ServerSocket(9000);
    }

    public void waitForConnections() throws IOException
    {
        System.out.println("Waiting for connections ...");
        this.socket = serverSocket.accept();
        this.dis = new DataInputStream(socket.getInputStream());
    }

    public String readNextBatch() throws IOException
    {
        if (dis == null)
        {
            throw new RuntimeException("No input stream");
        }
        else
        {
            return dis.readUTF();
        }
      }

    @Override
    public void close() throws IOException
    {
        serverSocket.close();
        dis.close();
    }
}
