package exercise;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class MessagesAggregator
{
    private static final int DEFAULT_WRITE_BATCH_SIZE = 1000;
    private BigInteger sumDataPoint5;
    private Set<String> uniqueUsers;
    private HashMap<String, Double> userIdToSumDataPoint3;
    private HashMap<String, Integer> userIdToCountMessages;
    private HashMap<String, String> userIdToRecentValueDataPoint4;
    private int aggregationBatchSize;

    public MessagesAggregator(int aggregationBatchSize)
    {
        this.aggregationBatchSize = aggregationBatchSize;
        reinitializeStatistic();
    }

    public MessagesAggregator()
    {
        this.aggregationBatchSize = DEFAULT_WRITE_BATCH_SIZE;
        reinitializeStatistic();
    }

    public void aggregateStatistic(String[] dataPoints)
    {
        String userId = dataPoints[0];

        uniqueUsers.add(dataPoints[0]);
        sumDataPoint5 = sumDataPoint5.add(new BigInteger(dataPoints[4]));
        userIdToSumDataPoint3.merge(userId, Double.parseDouble(dataPoints[2]), (v1, v2) -> (v1 + v2));
        userIdToCountMessages.merge(userId, 1, (v1, v2) -> v1 + v2);
        userIdToRecentValueDataPoint4.put(userId, dataPoints[3]);
    }

    public void writeDataStatisticToFile(int fileNumber) throws IOException
    {
        try (FileWriter fileWriter = new FileWriter(String.format("%s.csv", fileNumber));)
        {
            PrintWriter printWriter = new PrintWriter(fileWriter);

            printWriter.println(sumDataPoint5.toString());
            printWriter.println(uniqueUsers.size());

            for (String userId : uniqueUsers)
            {
                printWriter.print(userId);
                printWriter.print(",");
                printWriter.print(userIdToSumDataPoint3.get(userId) /  userIdToCountMessages.get(userId));
                printWriter.print(",");
                printWriter.println(userIdToRecentValueDataPoint4.get(userId));
            }

        }
    }

    public void reinitializeStatistic()
    {
        sumDataPoint5 = BigInteger.ZERO;
        uniqueUsers = new HashSet<>();
        userIdToSumDataPoint3 = new HashMap<>();
        userIdToCountMessages = new HashMap<>();
        userIdToRecentValueDataPoint4 = new HashMap<>();
    }

    public int getAggregationBatchSize()
    {
        return aggregationBatchSize;
    }
}
